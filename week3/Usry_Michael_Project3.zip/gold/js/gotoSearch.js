function getID(x) {
	var elementID = document.getElementById(x);
	return elementID;
};

// **************************************************************
// Search added for project II
var search = getID('search-basic');
search.addEventListener("click", search.html);
